/**
 * Created by zfc on 2017/2/14.
 */
import React, { Component } from 'react';
// import { push } from 'react-router-redux';
// import * as homeAction from 'redux/modules/home';
// import {ProductInfo, HomePagingBar} from 'components';

export default class Home extends Component {
  static propTypes = {
  }

  constructor() {
    super();
  }

  render() {
    return (
      <div>
        <ul>
          <li className="eat" >12</li>
        </ul>
      </div>
    );
  }
}
